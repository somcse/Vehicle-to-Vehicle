function validateSimulation(P, H, log)
% VALIDATESIMULATION  – Run unit, synthetic & system‐level checks
%   P   : parameter struct (from init.m)
%   H   : history buffers (positions, speeds, etc.)
%   log : detailed PSO/QP logs

    fprintf('\n=== Running Validation Suite ===\n');

    % 1) Unit Tests for Risk Function
    testRiskFunction(P);
    fprintf('✔ Risk function unit tests passed.\n');

    % 2) QP Feasibility & Bounds Tests
    testLowerQPVeh(P);
    fprintf('✔ QP feasibility tests passed.\n');

    % 3) PSO convergence on a toy quadratic cost
    testPSOToy();
    fprintf('✔ PSO convergence on toy cost passed.\n');

    % 4) Synthetic benchmark: Leader–Follower
    bench1 = benchmarkLeaderFollower(P);
    fprintf('Leader–Follower → RMSE_v = %.3f, minHeadway = %.2f\n', ...
            bench1.rmseVel, bench1.minHeadway);

    % 5) Scalability study
    scal = benchmarkScalability([10,20,50], P);
    disp('Scalability results:');
    disp(scal);

    % 6) Baseline comparison
    comp = compareBaselines(P);
    disp('Baseline comparison:');
    disp(comp);

    % 7) Monte Carlo statistics
    mc = runMonteCarlo(50, P);
    fprintf('Monte Carlo → meanRisk = %.2f ± %.2f\n', mc.meanRisk, mc.stdRisk);

    % 8) Sensitivity analysis
    sens = sensitivityAnalysis(P, 'd_safe', [5,10,15,20]);
    disp('Sensitivity to d\_safe:');
    disp(sens);

    % 9) Plot validation figures
    plotValidationFigures(bench1, scal, comp, mc, sens);

    % 10) Generate and export all validation tables
    %generateValidationTables(P, H, log, bench1, scal, comp, mc, sens);
    generateValidationTables(P, H, log, comp, bench1);


    fprintf('=== Validation Suite Complete ===\n\n');
end

%% ------------------------------------------------------------------------
function testRiskFunction(P)
    % Two‐vehicle headway test using P.v_max as cruise speed
    deltas = -5:5;
    x2 = P.d_safe + deltas;
    R = nan(size(deltas));
    for k = 1:numel(deltas)
        x = [0; x2(k)];
        y = [0; 0];
        vPrev = [P.v_max; P.v_max];             % use v_max
        v_i   = P.v_max;                        % candidate speed at cruise
        R(k) = computeIndividualRisk([1,1,1], 1, 2, x, y, vPrev, v_i, P);
    end
    % Risk should be ~0 when headway ≥ d_safe
    assert(all(R(deltas>=0) < 1e-6), 'Risk >0 when headway ≥ d_safe');
    % As headway decreases (deltas: -1,-2,...), risk should increase
    idx = deltas < 0;
    diffs = diff(R(idx));
    assert(all(diffs < 0), 'Risk not increasing as headway decreases');
end

%% ------------------------------------------------------------------------
function testLowerQPVeh(P)
    % QP should succeed and produce vOpt in [v_min,v_max]
    x = [0; P.d_safe-1];
    y = [0; 0];
    vPrev = [10; 10];
    [vOpt, qps] = lowerQPVeh_perVehicle([1,1,1], 1, 2, x, y, vPrev, P);
    assert(qps.exitflag > 0, 'QP solver failed');
    assert(vOpt >= P.v_min && vOpt <= P.v_max, 'vOpt out of bounds');
end

%% ------------------------------------------------------------------------
function testPSOToy()
    % PSO should find minimum of f(w)=||w-0.5||^2
    Ptoy = struct();
    Ptoy.swarm     = 30;
    Ptoy.psoIter   = 100;
    Ptoy.w0        = 0.9;
    Ptoy.wf        = 0.4;
    Ptoy.c1        = 1.5;
    Ptoy.c2        = 1.5;
    Ptoy.b_max     = 1;
    Ptoy.lam_max   = 1;
    Ptoy.logPbest  = false;
    Ptoy.boundMode = 'clip';
    costFun = @(W) sum((W - 0.5).^2, 2);
    [wBest, ~] = psoStep_basicPlus(costFun, Ptoy);
    assert(all(abs(wBest - 0.5) < 0.1), 'PSO failed to find 0.5 optimum');
end
%{
%% ------------------------------------------------------------------------
function result = benchmarkLeaderFollower(P)
    % Two-vehicle leader-follower over T=5s
    Ttest = 5;
    dt = P.dt;
    steps = floor(Ttest/dt) + 1;
    P2 = P; P2.N = 2; P2.roadL = 2*P.roadL;
    x = [0; -10];
    y = [0;  0];
    v = [P.v_max; P.v_max];
    for k = 1:steps
        neigh = neighborDetection(x, y, P2);
        [vOpt, ~] = lowerQPVeh_perVehicle([1,1,1], 2, neigh{2}, x, y, v, P2);
        v(2) = vOpt;
        x = x + v*dt;
    end
    rmseVel    = sqrt(mean((v(2) - P.v_max).^2));
    headway    = x(2) - x(1);
    result.rmseVel    = rmseVel;
    result.minHeadway = headway;
end
%}
function result = benchmarkLeaderFollower(P)
    % Two-vehicle leader–follower over T=5s; checks that follower never
    % falls below d_safe behind the leader.

    Ttest = 5;
    dt    = P.dt;
    steps = floor(Ttest/dt)+1;

    %---- override for N=2 ----
    P2       = P;
    P2.N     = 2;
    P2.roadL = 2*P.roadL;    

    %---- start with leader ahead by exactly d_safe ----
    x = [P2.d_safe; 0];  
    y = [0; 0];
    v = [P2.v_max; P2.v_max];

    headways = nan(1, steps);
    for k = 1:steps
        % detect neighbours (will be mutual)
        neigh = neighborDetection(x, y, P2);

        % follower (index 2) solves its QP each step
        [vOpt, ~] = lowerQPVeh_perVehicle([1,1,1], 2, neigh{2}, x, y, v, P2);
        v(2) = vOpt;

        % advance both vehicles
        x = x + v*dt;

        % record leader-minus-follower gap
        headways(k) = x(1) - x(2);
    end

    % package results
    result.rmseVel    = sqrt(mean((v(2)-P2.v_max).^2));
    result.minHeadway = min(headways);

    % safety assertion
    assert(result.minHeadway >= P2.d_safe - 1e-6, ...
        'Follower violated safety headway: minHeadway = %.2f < d_safe = %.2f', ...
         result.minHeadway, P2.d_safe);
end

%% ------------------------------------------------------------------------
function tableOut = benchmarkScalability(Nlist, P)
    tableOut = table(Nlist', 'VariableNames', {'N'});
    runtimes = nan(size(Nlist));
    for idx = 1:numel(Nlist)
        Pn = P; Pn.N = Nlist(idx);
        x = rand(Pn.N,1)*Pn.roadL;
        y = rand(Pn.N,1)*Pn.roadW;
        runtimes(idx) = timeit(@() neighborDetection(x, y, Pn));
    end
    tableOut.Runtime = runtimes';
end

%% ------------------------------------------------------------------------
function tableOut = compareBaselines(P)
    x = rand(P.N,1)*P.roadL;
    y = rand(P.N,1)*P.roadW;
    vPrev = repmat(P.v_max, P.N,1);
    neigh = neighborDetection(x,y,P);
    Rfixed = arrayfun(@(i) computeIndividualRisk([1,1,1], i, neigh{i}, x, y, vPrev, P.v_max, P), 1:P.N);
    wBest = nan(3,P.N);
    for i = 1:P.N
        costFun = @(w)localTotalRisk(w,i,neigh{i},wBest(:,neigh{i}),x,y,vPrev,P);
        wBest(:,i) = psoStep_basicPlus(costFun, P);
    end
    Radapt = arrayfun(@(i) computeIndividualRisk(wBest(:,i), i, neigh{i}, x, y, vPrev, P.v_max, P), 1:P.N);
    tableOut = table(mean(Rfixed), mean(Radapt), 'VariableNames', {'Fixed','Adaptive'});
end

%% ------------------------------------------------------------------------
function stats = runMonteCarlo(nTrials, P)
    risks = nan(nTrials,1);
    for t = 1:nTrials
        % random initial state
        x = rand(P.N,1)*P.roadL;
        y = rand(P.N,1)*P.roadW;
        vPrev = repmat(P.v_max, P.N,1);
        neigh = neighborDetection(x, y, P);
        Ri = arrayfun(@(i) computeIndividualRisk([1,1,1], i, neigh{i}, x, y, vPrev, P.v_max, P), 1:P.N);
        risks(t) = mean(Ri);
    end
    stats.meanRisk = mean(risks);
    stats.stdRisk  = std(risks);
end

%% ------------------------------------------------------------------------
function sens = sensitivityAnalysis(P, field, vals)
    sens = table(vals', 'VariableNames', {field});
    mRisk = nan(size(vals));
    for k = 1:numel(vals)
        P2 = P;
        P2.(field) = vals(k);
        mc = runMonteCarlo(10, P2);
        mRisk(k) = mc.meanRisk;
    end
    sens.MeanRisk = mRisk';
end

%% ------------------------------------------------------------------------
function plotValidationFigures(bench1, scal, comp, mc, sens)
    figure; bar([bench1.rmseVel, bench1.minHeadway]);
    title('Leader–Follower Metrics');
    ylabel('Value');
    xticklabels({'RMSE_{v}','Min Headway'});
    
    figure; plot(scal.N, scal.Runtime, '-o');
    title('Scalability: Neighbor Detection Time');
    xlabel('N'); ylabel('Time (s)');
    
    figure; bar([comp.Fixed, comp.Adaptive]);
    title('Baseline Risk Comparison');
    legend('Fixed','Adaptive');
    ylabel('Mean Risk');
    
    figure; errorbar(1, mc.meanRisk, mc.stdRisk, 'o');
    title('Monte Carlo Risk');
    xlim([0.5 1.5]);
    set(gca,'XTick',1,'XTickLabel','Mean Risk');
    
    figure; plot(sens{:,1}, sens.MeanRisk, '-s');
    title('Sensitivity Analysis');
    xlabel(sens.Properties.VariableNames{1});
    ylabel('Mean Risk');
end
