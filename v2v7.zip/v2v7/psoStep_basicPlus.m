function [bestW, history] = psoStep_basicPlus(costFun, P)
% PSOSTEP_BASICPLUS – Particle‑Swarm Optimisation with rich diagnostics.
% -------------------------------------------------------------------------
% PURPOSE
%   Evolves a 3‑D swarm (weights [b₁ b₂ λ]) toward minimal cost provided by
%   *costFun*, while logging extra metrics for convergence analysis.
% -------------------------------------------------------------------------
% INPUTS
%   costFun : function handle – costFun(W) where W is swarm×3 matrix.
%   P       : struct – must contain PSO and bound parameters listed below.
%             Optional fields: .logPbest (bool, default false),
%                              .boundMode  'clip'|'reflect' (default 'clip').
% -------------------------------------------------------------------------
% OUTPUTS
%   bestW   : 1×3 vector – best weight triplet found (global best).
%   history : struct – fields logged at every iteration:
%               • gCost         – scalar best cost trace
%               • gBestTrace    – trajectory of global‑best point
%               • diversity     – mean std‑dev of particle positions
%               • pCost         – raw cost of each particle per iter
%               • pBestCost     – (optional) personal‑best cost trace
%               • posFinal      – swarm position matrix at last iter
% -------------------------------------------------------------------------
% REVISION HISTORY
% fixed scalar‑cost bug when costFun not vectorised
% -------------------------------------------------------------------------

% === 0 · Optional parameter defaults -------------------------------------
if ~isfield(P,'logPbest'),  P.logPbest  = false;     end  % default: don’t log pBest
if ~isfield(P,'boundMode'), P.boundMode = "clip";   end  % default: clip it!

% === 1 · Basic constants --------------------------------------------------
swarm = P.swarm;             % number of particles
D     = 3;                   % search‑space dimension (b₁, b₂, λ)

% Bounds for each dimension (vectors 1×D)
lb = [0.1 0.1 0.1];
ub = [P.b_max P.b_max P.lam_max];

% === 2 · Swarm initialisation -------------------------------------------
pos = rand(swarm, D) .* (ub - lb) + lb;  % random init uniformly within bounds
vel = zeros(swarm, D);                  % initial velocities set to zero

pBest = pos;                            % personal‑best positions (start = init)
pCost =  inf(swarm, 1);                 % personal‑best costs (∞ so any real cost wins)
[gCost, idx] = min(pCost);              % global‑best cost (∞ initially)
gBest       = pBest(idx, :);            % global‑best position

% === 3 · Pre‑allocate history buffers ------------------------------------
history.pCost      = zeros(P.psoIter, swarm); % cost of each particle each iter
history.gCost      = zeros(P.psoIter, 1);     % best cost trace
history.gBestTrace = zeros(P.psoIter, D);     % gBest trajectory
history.diversity  = zeros(P.psoIter, 1);     % mean std‑dev of swarm spread
if P.logPbest
    history.pBestCost = zeros(P.psoIter, swarm); % personal‑best cost trace
end

% === 4 · PSO main loop ----------------------------------------------------
for it = 1:P.psoIter
    % --- 4a · Dynamic inertia weight (linear decay) ----------------------
    wInertia = P.w0 + (P.wf - P.w0) * it / P.psoIter;

    % --- 4b · Evaluate cost for each particle ----------------------------
    % First attempt vectorised evaluation (faster) and fall back to loop.
    vectorisedOK = false;
    try
        cost = costFun(pos);            % user‑supplied func on full matrix
        vectorisedOK = true;
    catch
        vectorisedOK = false;           % costFun not vectorised or threw error
    end

    % Validate vectorisation result: must be column vector length = swarm.
    if vectorisedOK
        if ~isvector(cost) || numel(cost) ~= swarm
            vectorisedOK = false;       % malformed → revert to loop
        else
            cost = cost(:);            % ensure column format
        end
    end

    % Scalar fallback – loop across particles with arrayfun.
    if ~vectorisedOK
        cost = arrayfun(@(row) costFun(pos(row, :)), 1:swarm).';
    end

    % --- 4c · Update history and personal/global bests -------------------
    history.pCost(it, :) = cost.';      % store raw costs
    if P.logPbest, history.pBestCost(it, :) = pCost.'; end

    better          = cost < pCost;     % logical vector: 1 if improvement
    pCost(better)   = cost(better);     % replace improved personal costs
    pBest(better, :)= pos(better, :);   % and positions

    [gCost, idx] = min(pCost);          % global best among all pBest
    gBest        = pBest(idx, :);

    history.gCost(it)       = gCost;    % log gBest cost
    history.gBestTrace(it,:)= gBest;    % log gBest position
    history.diversity(it)   = mean(std(pos, 0, 1)); % spatial diversity

    % --- 4d · PSO velocity & position update -----------------------------
    r1 = rand(swarm, D);  r2 = rand(swarm, D);   % fresh random matrices
    vel = wInertia * vel ...                    % inertia term
        + P.c1 * r1 .* (pBest - pos) ...        % cognitive attraction
        + P.c2 * r2 .* (gBest - pos);           % social attraction

    pos = pos + vel;                            % Euler step

    % --- 4e · Bound‑handling ------------------------------------------------
    switch lower(P.boundMode)
        case 'clip'                              % clamp to [lb, ub]
            pos = max(min(pos, ub), lb);
        case 'reflect'                           % reflect off boundaries
            overU  = pos > ub;    underL = pos < lb;
            pos(overU)  = ub(overU)  - (pos(overU)  - ub(overU));
            pos(underL) = lb(underL) + (lb(underL) - pos(underL));
            vel(overU | underL) = -vel(overU | underL); % invert vel component
    end
end

% === 5 · Package results --------------------------------------------------
bestW = gBest;                 % return best weight triplet
history.posFinal = pos;        % final swarm distribution (for diagnostics)
end