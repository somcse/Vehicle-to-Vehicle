function plotLogs(log, P, dt)
% plotLogs – Diagnostic figures for the V2V platoon simulation.
%
% Inputs
%   log – struct: x, y, v, rInd, rTot, gBestCost, neigh…
%   P   – struct: N, roadL, roadW, (optional) dt
%   dt  – timestep [s] (optional; falls back to P.dt)
%
% REV 3.2
%   • Heat‑map uses imagesc + numeric labels (always compatible)
%   • Zero references to HeatmapChart.Colorbar
% -------------------------------------------------------------------------

    %% Ensure dt exists
    if nargin < 3 || isempty(dt)
        if isfield(P,'dt'), dt = P.dt;
        else, error('plotLogs: dt missing (pass it or set P.dt)'); end
    end

    %% Derived quantities
    N  = P.N;
    K  = size(log.x,2);
    tt = (0:K-1) * dt;
%{
    %% 1) Local‑total‑risk heat‑map with numeric labels
    clipPct = 98;
    Rraw    = log.rTot;
    clipMax = prctile(Rraw(:), clipPct);
    Rplot   = min(Rraw, clipMax);

    figure('Name','Local‑Total Risk (heat‑map + numbers)');
    imagesc(tt, 1:N, Rplot);  set(gca,'YDir','normal');
    colormap(parula(128));
    cb = colorbar; ylabel(cb, sprintf('Risk (≤ %.0f)', clipMax));
    xlabel('time [s]'); ylabel('vehicle #');
    title('Local‑Total Risk');

    % Overlay rounded values
    for i = 1:N
        for j = 1:K
            text(tt(j), i, sprintf('%.0f', Rplot(i,j)), ...
                'HorizontalAlignment','center', 'FontSize', 6, 'Color', 'k');
        end
    end
%}
% 1. Clip percentile
clipPct = 98;
Rraw = log.rTot;

% 2. Define original time vector (tt) and resolution
original_time = tt;              % Original time vector
Fs = 1 / mean(diff(tt));         % Original sampling frequency (Hz)

% 3. Define new time vector with 1-second resolution
t1 = ceil(min(tt));              % Round up start time
t2 = floor(max(tt));             % Round down end time
tt_1s = t1:1:t2;                 % New time vector with 1s steps
K1 = length(tt_1s);             % New time steps

% 4. Downsample or average the Rraw data to 1s resolution
Rplot = zeros(N, K1);
for k = 1:K1
    idx = find(tt >= tt_1s(k) & tt < tt_1s(k) + 1);  % 1-second window
    if ~isempty(idx)
        Rplot(:, k) = mean(Rraw(:, idx), 2);         % Average over 1 sec
    else
        Rplot(:, k) = NaN;                           % Fill NaN if no data
    end
end

% 5. Clip max for better visualization
clipMax = prctile(Rplot(~isnan(Rplot)), clipPct);
Rplot = min(Rplot, clipMax);

% 6. Plot heatmap with numbers
figure('Name','Local‑Total Risk (heat‑map + numbers)');
imagesc(tt_1s, 1:N, Rplot);  set(gca,'YDir','normal');
colormap(parula(128));
cb = colorbar; ylabel(cb, sprintf('Risk (≤ %.0f)', clipMax));
xlabel('Time [s]'); ylabel('Vehicle #');
title('Local‑Total Risk');

% 7. Overlay numeric labels
for i = 1:N
    for j = 1:K1
        if ~isnan(Rplot(i, j))
            text(tt_1s(j), i, sprintf('%.0f', Rplot(i, j)), ...
                'HorizontalAlignment','center', 'FontSize', 6, 'Color', 'k');
        end
    end
end

    %% 2) PSO convergence per vehicle (if available)
    if isfield(log,'gBestCost')
        for veh = 1:N
            figure('Name',sprintf('PSO Convergence – Veh %d',veh));
            plot(tt, squeeze(log.gBestCost(veh,:)), 'LineWidth', 1.5);
            xlabel('time [s]'); ylabel('gBest cost');
            title(sprintf('PSO Convergence – Vehicle %d',veh));
            grid on;
        end
    end

    %% 3) Neighbour graph at mid‑simulation
    snap = floor(K/2);
    edges = [];
    for i = 1:N
        nb = log.neigh{i,snap};
        edges = [edges; i*ones(numel(nb),1), nb(:)]; %#ok<AGROW>
    end
    if ~isempty(edges)
        G = graph(edges(:,1), edges(:,2));
        figure('Name','Neighbour Graph (mid‑sim)');
        plot(G, 'MarkerSize', 6, 'Layout', 'force');
        title(sprintf('Neighbour graph at t = %.1f s', tt(snap)));
    end

    %% 4) Per‑vehicle dashboards
    for veh = 1:N
        figure('Name',sprintf('Veh %d Dash',veh), ...
               'Units','normalized','Position',[.2 .2 .6 .5]);
        tiledlayout(1,4,'TileSpacing','compact','Padding','compact');

        nexttile;
        plot(tt, squeeze(log.rInd(veh,:)), 'LineWidth', 1.3);
        title('Indiv Risk'); xlabel('s'); ylabel('risk'); grid on; axis square;

        nexttile;
        plot(tt, squeeze(log.rTot(veh,:)), 'LineWidth', 1.3);
        title('Local Risk'); xlabel('s'); ylabel('risk'); grid on; axis square;

        nexttile;
        plot(tt, squeeze(log.v(veh,:)), 'LineWidth', 1.3);
        title('Velocity'); xlabel('s'); ylabel('m/s'); grid on; axis square;

        nexttile;
        nc = arrayfun(@(k) numel(log.neigh{veh,k}), 1:K);
        stairs(tt(tt<=20), nc(tt<=20), 'LineWidth', 1.3);
        title('Neighbours (0‑20 s)'); xlabel('s'); ylabel('#'); grid on; axis square;
    end

    %% 5) Final inter‑vehicle distances (matrix + heat‑map with numbers)
    xf = log.x(:,end);  yf = log.y(:,end);
    D  = nan(N);
    for i = 1:N
        for j = i+1:N
            d        = hypot(xf(i)-xf(j), yf(i)-yf(j));
            D(i,j)   = d;  D(j,i) = d;
        end
    end

    figure('Name','Final Distances (matrix)');
    imagesc(1:N,1:N,D); set(gca,'YDir','normal'); axis equal tight;
    xlabel('j'); ylabel('i'); title('Final Distances');
    cb2 = colorbar; ylabel(cb2,'m');

    % numeric labels on distance matrix
    for i = 1:N
        for j = 1:N
            if ~isnan(D(i,j))
                text(j,i,sprintf('%.1f',D(i,j)), ...
                    'HorizontalAlignment','center', 'FontSize',6,'Color','k');
            end
        end
    end
end