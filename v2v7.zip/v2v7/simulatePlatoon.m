function [H, log] = simulatePlatoon(P)
% SIMULATEPLATOON  – Run one full platoon sim and return H & log structs.
%   P.usePSO        (bool) – if false, skip PSO and use fixed [1,1,1]
%   P.randomWeights (bool) – if true, randomise w each step instead of PSO

    % 0) Initialization via init.m (script)
    init;  % this sets P, H.x, H.y, H.v, H.Ri, H.Rl, H.neigh and times

    % 1) Derive the number of steps from H.x
    nSteps = size(H.x, 2);

    % 2) Prepare logging
    log = initLogging(P, nSteps, P.swarm);

    % 3) Default flags
    if ~isfield(P,'usePSO'),        P.usePSO = true;       end
    if ~isfield(P,'randomWeights'), P.randomWeights = false; end

    % 4) Seed for non-PSO modes
    fixedW = [1;1;1];
    wPrev  = 0.5*[P.b_max; P.b_max; P.lam_max] * ones(1,P.N);

    % 5) Main simulation loop
    for k = 2:nSteps
        xCur  = H.x(:,k-1);
        yCur  = H.y(:,k-1);
        vPrev = H.v(:,k-1);

        neigh = neighborDetection(xCur, yCur, P);
        wPrevLocal = wPrev;  %#ok<NASGU>

        % Preallocate per-vehicle containers
        vNew   = zeros(P.N,1);
        Ri     = zeros(P.N,1);
        bestWk = zeros(3,P.N);
        pHist  = repmat(struct('gCost',[], 'diversity',[], 'pCost',[]), P.N,1);
        qpStat = repmat(struct('exitflag',0,'message','','slackSum',0), P.N,1);

        parfor i = 1:P.N
            neigh_i = neigh{i};

            % 5a) Choose weight
            if ~P.usePSO
                w_i = fixedW;
                trace_i = struct('gCost',nan,'diversity',nan,'pCost',nan);
            elseif P.randomWeights
                w_i = [rand*(P.b_max-0.1)+0.1;
                       rand*(P.b_max-0.1)+0.1;
                       rand*(P.lam_max-0.1)+0.1];
                trace_i = struct('gCost',nan,'diversity',nan,'pCost',nan);
            else
                wNeigh  = wPrevLocal(:,neigh_i);
                costFun = @(w)localTotalRisk(w, i, neigh_i, wNeigh, ...
                                             xCur, yCur, vPrev, P);
                [w_i, trace_i] = psoStep_basicPlus(costFun, P);
            end

            bestWk(:,i)        = w_i;
            pHist(i).gCost     = trace_i.gCost;
            pHist(i).diversity = trace_i.diversity;
            pHist(i).pCost     = trace_i.pCost;

            % 5b) QP speed update
            [vOpt, qps] = lowerQPVeh_perVehicle(w_i, i, neigh_i, ...
                                                xCur, yCur, vPrev, P);
            if isnan(vOpt), vOpt = vPrev(i); end
            vNew(i) = vOpt;
            Ri(i)   = computeIndividualRisk(w_i, i, neigh_i, ...
                                            xCur, yCur, vPrev, vOpt, P);
            qpStat(i) = qps;
        end

        % 5c) Local-total risk
        Rl = Ri;
        for i = 1:P.N
            Rl(i) = Rl(i) + sum(Ri(neigh{i}));
        end

        % 5d) Physics update
        [xNext, yNext, vNext, laneIdx] = applyPhysicalExtensions(...
            xCur, yCur, vNew, vPrev, laneIdx, neigh, P);

        % 5e) Write back into H
        H.x(:,k)     = xNext;
        H.y(:,k)     = yNext;
        H.v(:,k)     = vNext;
        H.Ri(:,k)    = Ri;
        H.Rl(:,k)    = Rl;
        H.neigh(:,k) = neigh;

        % 5f) Log diagnostics
        log = logStep(log, k, P, ...
                      xNext, yNext, vNext, neigh, ...
                      Ri, Rl, pHist, bestWk, qpStat);

        % 5g) Update async‐weights
        wPrev = bestWk;
    end

    % No plotting in this wrapper
end
