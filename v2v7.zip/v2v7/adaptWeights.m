function wOut = adaptWeights(wBase, idx, neighIdx, vPrev, P)
% ADAPTWEIGHTS – Dynamically tunes the PSO/QP weight triplet [b1 b2 λ] for a
%                single vehicle, *while the simulation is running*.
%
% INPUTS
%   wBase    : 1×3 vector of “base” weights [b1 b2 λ] that a PSO particle
%              currently proposes for this vehicle before local adjustment.
%   idx      : Index of the **current vehicle i** whose weights we are
%              adapting (scalar, 1…P.N).
%   neighIdx : Row vector of indices of i’s current neighbours, as found by
%              the neighbour-detection module (can be empty).
%   vPrev    : Column vector (P.N×1) of vehicles’ *last-timestep* speeds.
%              Needed here so we can compare i’s speed against v_max.
%   P        : Parameter struct.  Only the fields used here are:
%                • P.maxNbrs  – (cap) maximum neighbours considered
%                • P.v_max    – fleet-wide speed limit used as “target”
%
% OUTPUT
%   wOut     : 1×3 vector – the locally-adapted weights to feed into the
%              cost/risk function for vehicle i at this instant.
%
% STRATEGY
%   1) **Consensus weight b2** grows with local density ρ:
%         ρ = (#neighbours around i) / (max possible neighbours)
%      Intuition – the more crowded the surroundings, the more strongly we
%      want vehicle i to align its velocity with its peers (consensus term).
%
%   2) **Speed-penalty weight λ** grows with the *normalised* speed error:
%         |v_i − v_max| / v_max
%      Intuition – if i is far from the desired cruise speed v_max, we
%      penalise that deviation more heavily in the optimisation.
%
%   b1 (collision-avoidance weight) is *left untouched* here; it already
%   scales with headway separately inside the risk function.

%--------------------------------------------------------------------------

% ❶ Extract the three base weights for readability
b1  = wBase(1);        % Collision / separation term (unchanged)
b2  = wBase(2);        % Consensus (to be density-scaled)
lam = wBase(3);        % Speed penalty (to be error-scaled)

% ❷ ----- Density-based scaling for b2 ------------------------------------

% Compute local “density ratio” ρ.
if isfield(P,'maxNbrs') && P.maxNbrs > 0
    % If the model explicitly caps #neighbours, normalise by that cap.
    rho = numel(neighIdx) / P.maxNbrs;
else
    % Fallback: normalise by fleet size minus self (worst-case crowding).
    %  max(1, …) guards against divide-by-zero when fleet size is 1.
    rho = numel(neighIdx) / max(1, numel(vPrev) - 1);
end

% Linearly inflate b2:  b2_new = b2_base × (1 + ρ)
%  – ρ = 0 ➔ no crowd, keep original
%  – ρ = 1 ➔ maximum crowd, double the consensus weight
b2 = b2 * (1 + rho);

% ❸ ----- Speed-error-based scaling for λ ---------------------------------

% Normalised absolute speed error for current vehicle i
v_err_norm = abs(vPrev(idx) - P.v_max) / P.v_max;

% Inflate λ proportionally:  λ_new = λ_base × (1 + |Δv|/v_max)
lam = lam * (1 + v_err_norm);

% ❹ Pack the adapted weights back into a row vector for output
wOut = [b1, b2, lam];
end
