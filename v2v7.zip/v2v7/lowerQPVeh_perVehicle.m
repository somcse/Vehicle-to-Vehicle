function [v_opt, qpStatus] = lowerQPVeh_perVehicle(w, i, neigh, x, y, vPrev, P)
% LOWERQPVEH_PERVEHICLE – Solves a *single‑vehicle* quadratic programme (QP)
% within the decentralised PSO‑QP framework.
% -------------------------------------------------------------------------
% DECISION VECTOR (nVar×1)
%   z = [v_i, s_1, …, s_Ni]ᵀ
%       v_i   – ego vehicle’s speed to decide
%       s_k   – non‑negative slack for the k‑th neighbour constraint
%               (softens the safety gap inequality)
%
% OBJECTIVE  (quadratic, convex)
%   J(z) = (λ + b₁·N_i)·(v_i − v_ref)²     +  b₂·Σ s_k²   +  b₂·v_max·Σ s_k
%          └── speed + consensus term ───┘    └ slack L2 ┘   └  slack L1 ┘
%
% CONSTRAINTS
%   • Safety‑gap (one per neighbour j):
%         Δt·v_i  −  s_k  ≤  (x_j − x_i) − d_safe + Δt·v_j
%   • Speed box:  v_min ≤ v_i ≤ v_max
%   • Non‑negativity: s_k ≥ 0
%
% OUTPUTS
%   v_opt            – optimal speed (NaN if solver failed)
%   qpStatus.exitflag – standard quadprog exit flag (>0 means success)
%   qpStatus.message  – solver diagnostic string
%   qpStatus.slackSum – Σ s_k at optimum (measure of residual violation)
%
% REVISION HISTORY
%   4.0 · 26‑Jun‑2025 – initial QP formulation by ChatGPT‑o3
% -------------------------------------------------------------------------

% === 0 · Unpack PSO weight vector ----------------------------------------
b1  = w(1);                % consensus weight
b2  = w(2);                % collision/slack weight
lam = w(3);                % speed‑deviation weight

% === 1 · Problem dimensions ---------------------------------------------
Ni   = numel(neigh);       % number of active neighbours for vehicle i
nVar = 1 + Ni;             % total decision variables (speed + Ni slacks)

% === 2 · Build quadratic objective matrices (H, f) ----------------------
H = zeros(nVar);           % Initialise H (nVar×nVar) with zeros
f = zeros(nVar,1);         % Linear term vector (nVar×1)

% --- 2a · Quadratic coefficients ----------------------------------------
% Diagonal element for v_i (index 1).
% Add a small ε to avoid singular H if lam+b1*Ni == 0.
diag_v   = lam + b1*Ni;
% All slack variables share the same diagonal coefficient (b2).
diag_slk = b2;
% Regularisation epsilon to guarantee positive definiteness
eps_reg  = 1e-6;
H(1,1)            = 2*max(diag_v,  eps_reg);            % 2*α for MATLAB’s ½zᵀHz convention
H(2:end,2:end)    = 2*max(diag_slk,eps_reg)*eye(Ni);    % scaled identity for slacks

% --- 2b · Linear coefficients -------------------------------------------
% Reference speed for comfort term (choose v_max = desired cruise)
v_ref   = P.v_max;
% Linear part w.r.t v_i  (comes from expanding (v_i−v_ref)² and consensus)
f(1)    = -2*(lam*v_ref + b1*sum(vPrev(neigh)));
% Linear part w.r.t each slack  (b2·v_max term)
f(2:end)= 2*b2*v_ref;

% === 3 · Build inequality constraint matrices (A, b) --------------------
A      = zeros(Ni, nVar);  % Ni constraints × nVar variables
b_vec  = zeros(Ni,1);
for k = 1:Ni
    j        = neigh(k);                                   % index of neighbour j
    dx       = hypot(x(j) - x(i), y(j) - y(i));            % Euclidean distance
    rhs      = dx - P.d_safe + P.dt * vPrev(j);            % right‑hand side of inequality
    A(k,1)   =  P.dt;                                       % coeff for v_i
    A(k,1+k) = -1;                                          % coeff for slack s_k
    b_vec(k) =  rhs;                                       % constant term
end

% === 4 · Variable bounds -------------------------------------------------
lb = [P.v_min; zeros(Ni,1)];   % v_i ≥ v_min,  slacks ≥ 0
ub = [P.v_max;  Inf(Ni,1)];    % v_i ≤ v_max,  slacks unbounded above

% === 5 · quadprog options -------------------------------------------------
opts = optimoptions('quadprog', 'Display','off', ...
        'TolFun',1e-8, 'TolX',1e-8);       % tight tolerances, silent run

% === 6 · Solve QP --------------------------------------------------------
try
    [sol, ~, exitflag, output] = quadprog(H, f, A, b_vec, [], [], lb, ub, [], opts);
catch ME                           % catch runtime errors (e.g. license issues)
    v_opt = NaN;
    qpStatus.exitflag = -2;        % custom failure code (quadprog threw error)
    qpStatus.message  = ['quadprog error: ', ME.message];
    qpStatus.slackSum = NaN;
    return
end

% === 7 · Package solver diagnostics -------------------------------------
qpStatus.exitflag = exitflag;      % >0 success, 0 max iter, <0 failure
qpStatus.message  = output.message;

if exitflag > 0 && ~isempty(sol) && ~isnan(sol(1))
    v_opt = sol(1);                % optimal speed
    qpStatus.slackSum = sum(sol(2:end));  % Σ slacks ⇒ residual gap violation
else                                % solver reported failure
    v_opt = NaN;
    qpStatus.slackSum = NaN;
end
end