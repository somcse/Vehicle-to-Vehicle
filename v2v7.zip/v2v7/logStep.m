function log = logStep(log, k, P, ...
                       xCur, yCur, vCur, ...
                       neighCur, ...
                       rIndCur, rTotCur, ...
                       psoHist, bestW, ...
                       qpStatus)
% LOGSTEP – Records a single time‑step snapshot into the *log* structure.
% -------------------------------------------------------------------------
% The simulation pre‑allocates 4‑D / cell arrays inside *log*; this routine
% writes the k‑th slice so that downstream analysis and plotting can work
% with contiguous memory (no dynamic resizing during the loop).
% -------------------------------------------------------------------------
% INPUTS
%   log         – struct whose fields are N×nSteps (or similar) buffers.
%   k           – time‑index (integer ≥1) identifying the *current* column.
%   P           – parameter struct (only P.N is used here).
%   xCur,yCur   – N×1 current positions.
%   vCur        – N×1 current speeds.
%   neighCur    – N×1 cell array of neighbour‑index vectors for this step.
%   rIndCur     – N×1 vector of individual risks  R_i  at this step.
%   rTotCur     – N×1 vector of local‑total risks R_l  at this step.
%   psoHist     – 1×N struct array, one element per vehicle, each holding
%                 convergence history of that vehicle’s PSO call.
%                 Fields used: .gCost, .diversity, (optional) .pCost.
%   bestW       – 3×N matrix: best weight vector [b₁ b₂ λ] found for each
%                 vehicle during the most recent PSO optimisation.
%   qpStatus    – 1×N struct array; fields used: .exitflag, .slackSum.
% -------------------------------------------------------------------------
% OUTPUT
%   log         – same struct handle, but with the k‑th slice filled.
% -------------------------------------------------------------------------
% -------------------------------------------------------------------------

N = P.N;                              % shorthand for fleet size

% === 1 · Store core kinematic state --------------------------------------
log.x(:, k) = xCur;                    % longitudinal positions (N×1 → col k)
log.y(:, k) = yCur;                    % lateral positions
log.v(:, k) = vCur;                    % speeds

% === 2 · Store neighbour information -------------------------------------
log.neigh(:, k) = neighCur;            % cell-per-vehicle neighbour lists

% === 3 · Store risk metrics ----------------------------------------------
log.rInd(:, k) = rIndCur;              % individual risk per vehicle
log.rTot(:, k) = rTotCur;              % local‑total risk per vehicle

% === 4 · Store PSO/QP diagnostics for *each* vehicle ---------------------
for i = 1:N
    % Best weight triplet found for vehicle i during its PSO call
    log.wBest(:, i, k) = bestW(:, i);

    % gBestCost – best cost encountered by the swarm; store the final one
    log.gBestCost(i, k) = psoHist(i).gCost(end);

    % diversity – swarm diversity metric at the last PSO iteration
    log.diversity(i, k) = psoHist(i).diversity(end);

    % Optional: pBestCost history present only if caller enabled logging
    if isfield(psoHist(i), 'pCost')
        % pCost(end, :) holds the last personal‑best cost of ALL particles
        log.pBestCost(:, i, k) = psoHist(i).pCost(end, :)';
    end

    % QuadProg diagnostic results -----------------------------------------
    log.qpExitflag(i, k) = qpStatus(i).exitflag; % solver exit flag
    log.qpSlack(i, k)    = qpStatus(i).slackSum; % sum of slack variables
end
end