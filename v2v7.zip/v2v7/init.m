%% init.m – Vehicle‑platooning: Parameters & Initialisation  (REV 4·26‑Jun‑2025)
% -------------------------------------------------------------------------
% This script prepares **all** simulation constants and initial state.
% It leaves three variables in the base workspace:
%   • P      – struct of parameters (immutable once simulation starts)
%   • H      – struct of history buffers (pre‑allocated matrices / cells)
%   • times  – 1×nSteps time grid from 0 to P.T_end in steps of P.dt
% The placement routine guarantees a centre‑to‑centre spacing ≥ 2·P.r.
% -------------------------------------------------------------------------

%% 0 · House‑keeping --------------------------------------------------------
clearvars;                 % purge any existing variables
clc;                       % clear command‑window text
rng(42);                   % reproducible randomness for placement / noise

%% 1 · Vehicle & road parameters -------------------------------------------
P.N      = 20;             % number of vehicles in the fleet
P.roadW  = 30;             % road width  (y‑axis)  [m]
P.roadL  = 2000;             % road length (x‑axis)  [m]
P.r      = 3;              % radius used in collision / spacing [m]
P.d_safe = 10;             % desired minimum headway (centre‑to‑centre) [m]

%% 2 · PSO & vehicle‑dynamics parameters -----------------------------------
P.dt      = .1;           % simulation time‑step [s]
P.T_end   = 20;             % total simulation duration [s]

P.v_max   = 30;            % hard speed limit   [m/s]
P.v_min   = 5;             % hard speed floor   [m/s]
P.a_max   =  2;            % maximum acceleration   [m/s²]
P.a_min   = -2;            % maximum deceleration   [m/s²]

P.b_max   = 5;             % PSO upper bound for consensus weight   b1
P.lam_max = 5;             % PSO upper bound for speed‑penalty wt  λ

P.swarm   = 50;            % particles per PSO swarm
P.psoIter = 500;           % PSO iterations per optimisation call
P.c1      = 1.5;           % cognitive coefficient
P.c2      = 1.5;           % social    coefficient
P.w0      = 0.9;           % inertia weight at iter 0 (exploration)
P.wf      = 0.4;           % inertia weight at last iter (exploitation)

%% 3 · Physical‑plausibility parameters (multi‑lane) -----------------------
P.nLanes      = 3;                                        % lanes across road
P.laneWidth   = P.roadW / P.nLanes;                       % width per lane [m]
P.laneCenters = linspace(P.laneWidth/2, ...               % y‑coords of lane centres
                         P.roadW - P.laneWidth/2, P.nLanes);
P.probLaneChange = 0.05;                                  % random lane‑change prob / step
P.sigmaAcc       = 0.5;                                   % σ of acceleration noise [m/s²]

%% 4 · Neighbourhood parameters -------------------------------------------
P.neighRadius = 50;          % interaction radius [m]
P.maxNbrs     = 5;           % cap on stored neighbours (performance)

%% 5 · Basic sanity checks --------------------------------------------------
assert(P.v_min < P.v_max, 'v_min must be < v_max');        % speed bounds order
assert(P.a_min < 0 && P.a_max > 0, 'Need a_min < 0 < a_max');
assert(P.swarm == floor(P.swarm) && P.swarm > 0, 'swarm must be a positive integer');
assert(rem(P.T_end, P.dt) < eps, 'T_end must be multiple of dt');
roadArea = P.roadW*P.roadL;  approxNeeded = P.N*pi*P.r^2;
assert(roadArea >= approxNeeded, 'Road too small for %d vehicles of radius %.2f m', P.N, P.r);

%% 6 · Non‑overlapping initial placement (two‑stage) -----------------------
[xCur, yCur] = tryPoissonThenGrid(P);  % returns valid positions (N×1 each)

%% 7 · Initial lanes & speeds ----------------------------------------------
laneIdx = randi(P.nLanes, P.N, 1);        % random starting lane (1…nLanes)
yCur    = P.laneCenters(laneIdx);         % snap y to lane centre
vNom    = (P.v_min + P.v_max) / 2;        % nominal mid‑range speed
vCur    = repmat(vNom, P.N, 1);           % every vehicle starts at vNom

%% 8 · History buffers & time vector ---------------------------------------
times  = 0:P.dt:P.T_end;                  % simulation time stamps
nSteps = numel(times);

H.x     = zeros(P.N, nSteps);             % longitudinal position log
H.y     = zeros(P.N, nSteps);             % lateral position log
H.v     = zeros(P.N, nSteps);             % speed log
H.Ri    = zeros(P.N, nSteps);             % individual risk log
H.Rl    = zeros(P.N, nSteps);             % local‑total risk log
H.neigh = cell(P.N, nSteps);              % cell array for neighbour lists

H.x(:,1) = xCur;                          % store initial state (k = 1)
H.y(:,1) = yCur;
H.v(:,1) = vCur;

disp('Initialisation complete – variables P, H, and times are ready.');

% -------------------------------------------------------------------------
%% LOCAL FUNCTIONS  (MATLAB ≥ R2020b allows functions in scripts) ----------
% -------------------------------------------------------------------------
function [x, y] = tryPoissonThenGrid(P)
% Attempt Bridson Poisson‑disc placement; fall back to grid if spacing fails.
usePoisson  = true;
maxRetries  = 4;              relaxFactor = 0.95;
minDist0    = 2*P.r;          minDist = minDist0;
placed      = false;

if usePoisson
    for attempt = 1:maxRetries
        [x, y] = poissonDisc2D(P.roadL, P.roadW, minDist, P.N, 40); % 40 = k (candidates)
        if spacingOK([x, y], 2*P.r, 1e-6)         % spacing satisfied ⇒ accept
            placed = true; break; end
        minDist = max(relaxFactor*minDist, 2*P.r);% relax constraint & retry
    end
end

if ~placed                                     % fallback strategy
    warning('Using deterministic grid placement (Poisson failed or too tight).');
    [x, y] = safeGridPlacement(P);
end

assert(spacingOK([x, y], 2*P.r, 1e-9), ...     % final guarantee
       'Overlap detected after final placement – this should not occur.');
end
% -------------------------------------------------------------------------
function ok = spacingOK(XY, minAllowed, tol)
% Return TRUE iff *all* pairwise distances ≥ minAllowed − tol.
if size(XY,1) < 2, ok = true; return; end      % 0/1 point ⇒ always OK
ok = min(pdist(XY)) >= (minAllowed - tol);     % pdist computes pairwise distances
end
% -------------------------------------------------------------------------
function [x, y] = poissonDisc2D(L, W, minD, N, k)
% Bridson fast Poisson‑disc sampler in rectangle [0,L]×[0,W].
if nargin<5, k = 30; end                       % default candidate count
cellSz = minD / sqrt(2);                      % grid cell size for O(1) search
gridL  = ceil(L/cellSz);   gridW = ceil(W/cellSz);
grid   = zeros(gridL, gridW);                 % store point indices per cell
pts    = zeros(N, 2); n = 0; active = [];

n = n + 1; pts(n,:) = [rand*L, rand*W];       % seed with first random point
active = n;
ci = floor(pts(n,1)/cellSz) + 1;              % grid coords of seed
cj = floor(pts(n,2)/cellSz) + 1; grid(ci,cj) = n;

while ~isempty(active) && n < N               % main Bridson loop
    idx = active(randi(numel(active)));       % choose random active point
    found = false;
    for t = 1:k                                % up to k candidates
        ang = 2*pi*rand;  rad = minD*(1+rand); % random annulus sample
        cand = pts(idx,:) + rad*[cos(ang) sin(ang)];
        if cand(1)<0 || cand(1)>L || cand(2)<0 || cand(2)>W, continue; end
        ci = floor(cand(1)/cellSz)+1;  cj = floor(cand(2)/cellSz)+1;
        i1 = max(ci-2,1);  j1 = max(cj-2,1);
        i2 = min(ci+2,gridL); j2 = min(cj+2,gridW);
        ok = true;
        for ii = i1:i2, for jj = j1:j2         % neighbourhood check
            p = grid(ii,jj);
            if p && norm(cand-pts(p,:)) < minD, ok=false; break; end
        end, if ~ok, break; end, end
        if ok
            n = n + 1; pts(n,:) = cand; active(end+1) = n;
            grid(ci,cj) = n; found = true; break;
        end
    end
    if ~found                                   % deactivate if no candidate accepted
        active(active == idx) = [];
    end
end
pts = pts(1:n, :);  x = pts(:,1);  y = pts(:,2); % output coordinates
end
% -------------------------------------------------------------------------
function [x, y] = safeGridPlacement(P)
% Deterministic rectangular lattice placement with ≥2r spacing.
maxCols = floor((P.roadL - 2*P.r) / (2*P.r)) + 1; % max columns that fit
maxRows = floor((P.roadW - 2*P.r) / (2*P.r)) + 1; % max rows that fit

for nCols = maxCols:-1:1                       % pick widest grid that fits N
    nRows = ceil(P.N / nCols);
    if nRows <= maxRows, break; end
end

dx = (P.roadL - 2*P.r) / max(nCols-1, 1);     % x spacing between centres
dy = (P.roadW - 2*P.r) / max(nRows-1, 1);     % y spacing between centres
xVec = P.r + (0:nCols-1) * dx;                % column x positions
yVec = P.r + (0:nRows-1) * dy;                % row    y positions
[Xg, Yg] = meshgrid(xVec, yVec);
sel = 1:P.N;                                   % take first N points row‑major
x = Xg(sel)';  y = Yg(sel)';
end
