function ri = computeIndividualRisk(w, i, neigh, x, y, vPrev, v_i, P, vCand)
% COMPUTEINDIVIDUALRISK  – Returns the scalar risk value r_i for vehicle i
%                          given its proposed speed   v_i   and the current
%                          local situation.
%
% Risk is a *sum of three quadratic terms*:
%     1) speed-deviation          (how far i is from its desired speed)
%     2) velocity consensus       (how different i is from its neighbours)
%     3) collision headway error  (how close i is to neighbours in x)
%
% INPUTS
%   w      : 1×3 vector   [ b1  b2  λ ]     ←  weights chosen by PSO
%   i      : scalar       index of the *current* vehicle
%   neigh  : row/col vec  indices of i’s neighbour vehicles
%   x, y   : N×1 vectors  current positions   (y unused but kept for API)
%   vPrev  : N×1 vector   speeds at t-1           (used if vCand omitted)
%   v_i    : scalar       candidate speed for vehicle i (from QP)
%   P      : struct       parameters (d_safe, v_max, v_des optional, …)
%   vCand  : N×1 vector   candidate speeds for *all* vehicles (optional);
%                         defaults to vPrev so the function is backwards-
%                         compatible when only i’s speed has changed.
%
% OUTPUT
%   ri     : scalar       total risk for vehicle i
%
% REVISION HISTORY
%-------------------------------------------------------------------------------

% --- 0) Optional argument handling -----------------------------------------
if nargin < 9                       % if caller did not pass vCand
    vCand = vPrev;                  % fall back to last-step speeds
end

% --- 1) Unpack / sanitise weights ------------------------------------------
b1  = w(1);                         % consensus weight
b2  = w(2);                         % collision weight
lam = max(w(3), 1e-6);              % speed-penalty weight, lower-bounded
                                     % (prevents numerical issues if λ=0)

% --- 2) Speed-deviation term ----------------------------------------------
% Desired speed: user can set P.v_des; otherwise cruise at v_max
if isfield(P,'v_des')
    v_des = P.v_des;
else
    v_des = P.v_max;
end
% Quadratic cost on deviation from desired speed
R_speed = lam * (v_i - v_des).^2;

% --- 3) Velocity consensus term -------------------------------------------
% deltaV is the vector of speed differences between neighbours and i
deltaV       = vCand(neigh) - v_i;
% Quadratic penalty encourages i to match neighbours’ speeds
R_consensus  = b1 * sum(deltaV.^2);

% --- 4) Collision (headway) term ------------------------------------------
% Compute axial gaps to neighbours (absolute x-distance)
dx     = abs(x(neigh) - x(i));
% If gap < d_safe, the deficit contributes quadratically
gap    = max(0, P.d_safe - dx);
R_coll = b2 * sum(gap.^2);

% --- 5) Total risk ---------------------------------------------------------
ri = R_speed + R_consensus + R_coll;
end
