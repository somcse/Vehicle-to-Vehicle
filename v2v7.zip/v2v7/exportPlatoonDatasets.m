function exportPlatoonDatasets(H, P, dt, times)
% exportPlatoonDatasets  –  Write key platoon metrics to CSV files.
%
% Inputs
%   H      – history struct (fields: v, Ri, Rl, x, y, neigh)
%   P      – parameter struct (field: N   ← # vehicles)
%   dt     – timestep size [s]
%   times  – 1×K vector of absolute time stamps [s]
%
% Output files created in the current folder:
%   velocity_dataset.csv
%   risk_individual.csv
%   risk_localTotal.csv
%   x_positions.csv
%   y_positions.csv
%   neigh_count.csv
% ----------------------------------------------------------------------

fprintf('Writing platoon datasets …\n');

% ---------- helper to build & write -----------------------------------
    function writeMatrixAsCSV(mat, fname, fmt)
        if nargin < 3, fmt = '%.3f'; end         % default format
        data    = [times(:) , mat.'];            % (K × (N+1))
        headers = [{'time'} , arrayfun(@(i)sprintf('Veh%02d',i), ...
                                       1:P.N, 'uni',0)];
        T       = array2table(data, 'VariableNames', headers);
        writetable(T, fname, 'Delimiter',',', 'FileType','text');
        fprintf('  → %s (%d rows × %d cols)\n', fname, size(T,1), size(T,2));
    end

% ---------- 1) velocity -------------------------------------------------
writeMatrixAsCSV(H.v, 'velocity_dataset.csv');

% ---------- 2) individual risk -----------------------------------------
writeMatrixAsCSV(H.Ri, 'risk_individual.csv');

% ---------- 3) local‑total risk ----------------------------------------
writeMatrixAsCSV(H.Rl, 'risk_localTotal.csv');

% ---------- 4) x & y positions -----------------------------------------
writeMatrixAsCSV(H.x, 'x_positions.csv');
writeMatrixAsCSV(H.y, 'y_positions.csv');

% ---------- 5) neighbour count -----------------------------------------
% Convert H.neigh (cell array) → numeric matrix (#veh × K)
nbMat = cellfun(@numel, H.neigh);   % same size as H.v
writeMatrixAsCSV(nbMat, 'neigh_count.csv', '%d');

fprintf('All datasets written successfully.\n\n');
end