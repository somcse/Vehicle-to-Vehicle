%% runSimulation.m – Master script to execute platoon simulation (REV 4)
% -------------------------------------------------------------------------
%  Steps:
%    1) init.m        – sets P, H, times, xCur, yCur, vCur, laneIdx
%    2) initLogging   – allocate log struct
%    3) Main loop     – PSO + QP + physics extension
%    4) Diagnostics   – plotLogs
%    5) Validation    – validateSimulation
% -------------------------------------------------------------------------

% 1) Initialization
init;                          % brings P, H, times into workspace
nSteps = numel(times);

% 2) Logging setup
log = initLogging(P, nSteps, P.swarm);

% Async weights seed
wPrev = 0.5 * [P.b_max; P.b_max; P.lam_max] .* ones(3, P.N);

% 3) Main simulation loop
for k = 2:nSteps
    xCur  = H.x(:,k-1);
    yCur  = H.y(:,k-1);
    vPrev = H.v(:,k-1);

    neighbors = neighborDetection(xCur, yCur, P);

    wPrevLocal = wPrev;   %#ok<NASGU>

    vNew   = zeros(P.N,1);
    Ri     = zeros(P.N,1);
    bestWk = zeros(3,P.N);
    pHist  = repmat(struct('gCost',[],'diversity',[],'pCost',[]),P.N,1);
    qpStat = repmat(struct('exitflag',0,'message','','slackSum',0),P.N,1);

    parfor i = 1:P.N
        neigh_i  = neighbors{i};
        wNeigh   = wPrevLocal(:,neigh_i);
        costFun  = @(w)localTotalRisk(w,i,neigh_i,wNeigh,...
                                       xCur,yCur,vPrev,P);

        [wBest_i, trace_i] = psoStep_basicPlus(costFun, P);
        bestWk(:,i)  = wBest_i.';
        pHist(i).gCost     = trace_i.gCost;
        pHist(i).diversity = trace_i.diversity;
        pHist(i).pCost     = trace_i.pCost;

        [vOpt, qps] = lowerQPVeh_perVehicle(wBest_i, i, neigh_i, ...
                                           xCur, yCur, vPrev, P);
        if isnan(vOpt), vOpt = vPrev(i); end
        vNew(i) = vOpt;
        Ri(i)   = computeIndividualRisk(wBest_i, i, neigh_i, ...
                                        xCur, yCur, vPrev, vOpt, P);
        qpStat(i) = qps;
    end

    % Local‑total risk
    Rl = Ri;
    for i = 1:P.N
        Rl(i) = Rl(i) + sum(Ri(neighbors{i}));
    end

    % Physics update
    [xNext,yNext,vNext,laneIdx] = applyPhysicalExtensions( ...
        xCur, yCur, vNew, vPrev, laneIdx, neighbors, P);

    % Write into history
    H.x(:,k)     = xNext;
    H.y(:,k)     = yNext;
    H.v(:,k)     = vNext;
    H.Ri(:,k)    = Ri;
    H.Rl(:,k)    = Rl;
    H.neigh(:,k) = neighbors;

    % Logging
    log = logStep(log, k, P, ...
                  xNext, yNext, vNext, ...
                  neighbors, ...
                  Ri, Rl, ...
                  pHist, bestWk, ...
                  qpStat);

    % Update weights
    wPrev = bestWk;

    % Console output
    if mod(k,10)==0 || k==nSteps
        fprintf('t=%.1f | v̄=%.2f | R̄=%.2f | QP-fails=%d\n', ...
                times(k), mean(vNext), mean(Rl), ...
                sum([qpStat.exitflag] <= 0));
    end
end

% ---------------- End of main loop ------------------

disp('Simulation finished – plotting logs …');

% guarantee dt exists for plotLogs
if ~exist('dt','var')
    if isfield(P,'dt')
        dt = P.dt;
    else
        error('runSimulation: dt variable not found and P.dt missing.');
    end
end

plotLogs(log, P, dt);    % --- diagnostics ---

% ------------------------------------------------------------
exportPlatoonDatasets(H, P, dt, times);
% ------------------------------------------------------------


% Validation (unit + system‑level checks)
validateSimulation(P, H, log);

