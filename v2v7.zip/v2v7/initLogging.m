
function log = initLogging(P, simSteps, swarm)
% initLogging  – Pre‑allocates all arrays used for run‑time logging.
%
%  REV 4 · 26‑Jun‑2025

N = P.N;      K = simSteps;

log.x     = NaN(N,K);
log.y     = NaN(N,K);
log.v     = NaN(N,K);

log.neigh = cell(N,K);

log.rInd  = NaN(N,K);
log.rTot  = NaN(N,K);

log.wBest      = NaN(3,N,K);
log.pBestCost  = NaN(swarm,N,K);
log.gBestCost  = NaN(N,K);
log.diversity  = NaN(N,K);

log.qpExitflag = NaN(N,K);
log.qpSlack    = NaN(N,K);
end
