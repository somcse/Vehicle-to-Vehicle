function Rtot = localTotalRisk(w, idx, neighIdx, wNeigh, ...
                                xCur, yCur, vPrev, P)
% LOCALTOTALRISK  – Computes the *local‑total* risk for vehicle *idx*.
% -------------------------------------------------------------------------
% • The risk comprises the ego vehicle’s own risk plus the individual
%   risks of its current neighbours.  Neighbour risks are evaluated with
%   the neighbour‑specific weight triplets contained in *wNeigh*.
% • "Asynchronous" means that each neighbour’s weight vector may stem from
%   a *previous* optimisation iteration; this reflects the distributed
%   nature of the algorithm where vehicles do *not* update perfectly in‑
%   sync.
% -------------------------------------------------------------------------
% INPUTS
%   w        (1×3)   – base weight vector [b₁ b₂ λ] proposed for *idx*.
%   idx      (scalar)– index of the *ego* vehicle (1…P.N).
%   neighIdx (vector)– indices of the current neighbours of *idx*.
%   wNeigh   (3×M)   – weight vectors for each neighbour (columns).
%   xCur     (N×1)   – current x‑positions of *all* vehicles.
%   yCur     (N×1)   – current y‑positions (unused here but kept for API).
%   vPrev    (N×1)   – speeds at the previous time step (baseline).
%   P        (struct)– global parameter block (see init.m).
% -------------------------------------------------------------------------
% OUTPUT
%   Rtot     (scalar) – local‑total risk perceived by vehicle *idx*.
% -------------------------------------------------------------------------
% REVISION HISTORY
% -------------------------------------------------------------------------

% === 1 · Select ego vehicle’s *candidate* speed ==========================
% Here we use the *previous* speed as the candidate because localTotalRisk
% is called *inside* the PSO cost evaluation stage, *before* the QP has
% updated vCur.  If you later integrate real‑time candidate speeds you can
% pass them as an extra argument.
v_i = vPrev(idx);

% === 2 · Adapt ego weights to the current micro‑environment ==============
% adaptWeights scales b₂ (consensus) by local density and λ (speed‑error)
% by the ego’s own speed deviation.  b₁ (collision) is left unchanged.
wEgo = adaptWeights(w, idx, neighIdx, vPrev, P);

% === 3 · Compute ego vehicle’s individual risk ===========================
% This risk accounts for: speed deviation, speed consensus with neighbours,
% and headway safety gaps.  The neighbour list supplied is *neighIdx*.
riSelf = computeIndividualRisk(wEgo, idx, neighIdx, ...
                               xCur, yCur, vPrev, v_i, P);

% === 4 · Accumulate neighbours’ risks (as seen from each neighbour) ======
riNei = 0;                                 % initialise accumulator
for k = 1:numel(neighIdx)                  % iterate through neighbours
    j = neighIdx(k);                       % global index of neighbour j
    w_j = wNeigh(:,k).';                   % weight vector for neighbour j

    % -- Risk for neighbour j --------------------------------------------
    % Neighbour j views *idx* as its only neighbour in this bilateral
    % evaluation; hence the neighbour list passed to computeIndividualRisk
    % is simply idx.  We use vPrev(j) as j’s candidate speed (same logic as
    % for the ego vehicle).
    riNei = riNei + computeIndividualRisk(w_j, j, idx, ...
                xCur, yCur, vPrev, vPrev(j), P);
end

% === 5 · Local‑total risk returned to the PSO cost function ==============
Rtot = riSelf + riNei;
end

