function neighbors = neighborDetection(xCur, yCur, P)
% NEIGHBORDETECTION – Identify nearby vehicles within a fixed radius.
% -------------------------------------------------------------------------
% INPUTS
%   xCur, yCur : N×1 numeric vectors – current positions of all vehicles.
%   P          : struct – fields used here:
%                   • N            (int)  – number of vehicles
%                   • neighRadius  (m)    – cut-off distance for neighbourhood
%                   • maxNbrs      (int)  – optional cap on stored neighbours
%
% OUTPUT
%   neighbors  : N×1 cell – neighbors{i} is a *row vector* of indices of all
%                               vehicles j such that  0 < dist(i,j) ≤ neighRadius.
%                               (Self-index i is excluded.)
% -------------------------------------------------------------------------
% ALGORITHM
%   1) Compute the full pairwise distance matrix D using pdist2 (O(N²)).
%   2) For each vehicle i:
%        • Find candidate indices within the radius, excluding i itself.
%        • If more than P.maxNbrs, keep the closest P.maxNbrs only.
%   3) Store the resulting index vector in the cell array.
% -------------------------------------------------------------------------

% === 1 · Pairwise Euclidean distances (2‑D) -------------------------------
D = pdist2([xCur, yCur], [xCur, yCur]);  % D(i,j) := sqrt( (x_i−x_j)² + (y_i−y_j)² )

% === 2 · Pre-allocate output cell array ----------------------------------
neighbors = cell(P.N, 1);              % neighbours{i} will be a row vector

% === 3 · Loop through each ego vehicle -----------------------------------
for i = 1:P.N
    % --- 3a · Candidate neighbour indices --------------------------------
    cand = find( D(i,:) > 0 & ...          % exclude self (distance > 0)
                 D(i,:) <= P.neighRadius); % within communication radius

    % --- 3b · Optional truncation to P.maxNbrs ---------------------------
    if numel(cand) > P.maxNbrs            % too many → keep the closest ones
        [~, order] = sort( D(i, cand), 'ascend');  % ascending distance order
        cand = cand( order(1:P.maxNbrs) );          % take first maxNbrs
    end

    % --- 3c · Store as row vector ----------------------------------------
    neighbors{i} = cand;                  % row orientation keeps output uniform
end
end