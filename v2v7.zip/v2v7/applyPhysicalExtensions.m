function [xNext, yNext, vNext, laneIdx] = ...
    applyPhysicalExtensions(xCur, yCur, vNew, vPrev, laneIdx, neighbors, P)
% APPLYPHYSICALEXTENSIONS  –  Adds extra realism to the 1-D PSO/QP simulation:
%                             • stochastic acceleration (“driver noise”)
%                             • lateral lane-change logic (multi-lane road)
%                             • simple collision guard in 2-D
%
%   INPUTS
%     xCur, yCur   – current positions along road-length (x) and road-width (y)
%     vNew, vPrev  – candidate speeds from optimiser and speeds at t-1
%     laneIdx      – current lane index for each vehicle   (1 = leftmost)
%     neighbors    – neighbour list (unused here but passed for interface)
%     P            – struct of global parameters; fields used here:
%                       dt            • simulation timestep
%                       v_min/v_max   • hard speed bounds
%                       sigmaAcc      • std-dev of acceleration noise
%                       probLaneChange• Bernoulli prob a driver tries to change
%                       nLanes        • total lanes on the road
%                       laneCenters   • y-coordinate of each lane centre
%                       d_safe        • required headway for safe lane entry
%                       r             • vehicle “radius” for collision test
%
%   OUTPUTS
%     xNext, yNext – updated positions (column vectors)
%     vNext        – updated speeds   (column vector)
%     laneIdx      – updated lane indices
%
%   fixed vector concatenation edge-case

%-------------------------------------------------------------------------%
% 0) House-keeping – ensure every input is a *column* vector so that the
%    subsequent vectorised operations behave consistently.
%-------------------------------------------------------------------------%
xCur    = xCur(:);
yCur    = yCur(:);
vNew    = vNew(:);
vPrev   = vPrev(:);
laneIdx = laneIdx(:);

N = numel(xCur);                         % fleet size

%-------------------------------------------------------------------------%
% 1) Longitudinal dynamics – add random acceleration noise (“human driver”)
%-------------------------------------------------------------------------%
% dvNoise ~ N(0, σ√dt)    (Euler–Maruyama discretisation of a Wiener process)
dvNoise = P.sigmaAcc * sqrt(P.dt) * randn(N,1);

% Candidate speed + noise, then clipped to [v_min, v_max]
vNext = vNew + dvNoise;
vNext = max(P.v_min, min(P.v_max, vNext));

%-------------------------------------------------------------------------%
% 2) Lane-change module
%    For each vehicle i independently:
%       • With probability probLaneChange, pick −1 / 0 / +1 lane shift
%       • Clamp inside road edges
%       • Check *prospective* lane for a safe gap (≥ d_safe)
%-------------------------------------------------------------------------%
for i = 1:N
    if rand < P.probLaneChange                     % “driver decides to move”
        laneCand = laneIdx(i) + randi([-1 1]);     % left (−1), stay (0), right (+1)
        laneCand = max(1, min(P.nLanes, laneCand));% keep within bounds
        if laneCand == laneIdx(i), continue; end   % if no actual change, skip

        % Target y-coordinate of that lane
        yTarget = P.laneCenters(laneCand);

        % Identify vehicles already in the target lane (y-positions == centre)
        sameLane = abs(yCur - yTarget) < 1e-6;

        % Headway distances to those vehicles
        dx = abs(xCur(sameLane) - xCur(i));

        % Safe to merge only if *all* headways ≥ d_safe
        if all(dx >= P.d_safe)
            laneIdx(i) = laneCand;                 % commit the lane change
        end
    end
end

%-------------------------------------------------------------------------%
% 3) Lateral kinematics – snap y to the exact lane centre after updates.
%    (No gradual lateral motion modelled for simplicity.)
%-------------------------------------------------------------------------%
yNext = P.laneCenters(laneIdx).';     % row vector
yNext = yNext(:);                     % back to column

%-------------------------------------------------------------------------%
% 4) Forward propagation of x (Euler step) with a simple collision guard
%    • First, move every vehicle forward by vNext * dt
%    • Then, detect any overlaps (< 2r) and “rollback” the faster of the
%      two by 50 % of its step to avoid inter-penetration.
%-------------------------------------------------------------------------%
xNext = xCur + vNext * P.dt;
xNext = xNext(:);                     % column

% Build pairwise distance matrix in 2-D
pts = [xNext, yNext];                 % (N×2)
D   = pdist2(pts, pts);               % (N×N) Euclidean distances

% Only need to check *unique* pairs below main diagonal
mask = tril(true(size(D)), -1);
[rowIdx, colIdx] = find(D < 2*P.r & mask);   % colliding pairs a,b

% Resolve each detected overlap
for k = 1:numel(rowIdx)
    a = rowIdx(k);  b = colIdx(k);
    if vNext(a) > vNext(b)
        % a is faster → move it only half its step
        xNext(a) = xCur(a) + 0.5 * vNext(a) * P.dt;
    else
        % b is faster (or equal) → trim b’s step instead
        xNext(b) = xCur(b) + 0.5 * vNext(b) * P.dt;
    end
end
end
